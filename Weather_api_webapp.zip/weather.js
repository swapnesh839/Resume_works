
const api = "3a37d265d219bccf2b55b44ae06bef7c";



let search_btn = document.getElementById("search_btn");
// document.addEventListener("DOMContentLoaded",result)
search_btn.addEventListener("click", result)
function result() {
    let city = document.getElementById("search").value;
    // console.log(city);
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=3a37d265d219bccf2b55b44ae06bef7c&units=metric`;
    async function weather() {
        const response = await fetch(url);
        let data = await response.json();
        // console.log("uuuu")

        document.getElementById("humidity").innerText = data.main.humidity;
        document.getElementById("temp").innerText = Math.round(data.main.temp);
        document.getElementById("wind").innerText = data.wind.speed;
        document.getElementById("city").innerText = city;
    }
    weather();
}
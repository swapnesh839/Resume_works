let btn = document.getElementById("btn");

const date = new Date();

let input = document.getElementById("date");
input.max = date.toISOString().split('T')[0];

btn.addEventListener("click", () => {
    if (input.value === "") {
        alert("The field can't be empty");
    } else {
        let birthday = new Date(input.value);
        let day1 = birthday.getDate();
        let month1 = birthday.getMonth() + 1;
        let year1 = birthday.getFullYear();

        let day2 = date.getDate();
        let month2 = date.getMonth() + 1;
        let year2 = date.getFullYear();

        let dd, mm, yy;

        yy = year2 - year1;

        if (month2 < month1) {
            yy--;
            mm = 12 + month2 - month1;
        } else {
            mm = month2 - month1;
        }

        if (day2 >= day1) {
            dd = day2 - day1;
        } else {
            mm--;
            dd = getDaysInmonth1(year1, month1) + day2 - day1;
        }

        if (mm < 0) {
            mm = 11;
            yy--;
        }

        const result = document.getElementById("result");
        result.innerText = `Your age is ${yy} years, ${mm} months, and ${dd} days`;

        console.log(yy, mm);
    }
});

function getDaysInmonth1(year, month1) {
    return new Date(year, month1, 0).getDate();
}

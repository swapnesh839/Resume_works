let x = "xxxxxx"

let ccc = `("${x}")`

console.log(ccc);


const quote = document.getElementById("quote")
const btn_new = document.getElementById("btn_new")
const btn_twiter = document.getElementById("btn_twiter")
const author = document.getElementById("author")
const api = "https://api.quotable.io/random/?maxLength=60";

let getQuote = async () => {
    const response = await fetch(api);
    const data = await response.json();
    // console.log(data);
    quote.innerText = `"${data.content}"`
    author.innerText = `"${data.author}"`
};

btn_twiter.addEventListener("click",()=>{
  window.open(`https://twitter.com/intent/tweet?text=${quote.innerText} ${"          --by"} ${author.innerText}`)
})

getQuote();

btn_new.addEventListener("click",()=>{
  getQuote();
})

const generate = document.getElementById("generate");
const copy = document.getElementById("copy");
const password = document.getElementById("password");



const lowerAlph = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];

const upperAlp = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
const number = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const Characters = ["@", "#",  "$", "%", "&"];


console.log(lowerAlph.length);

const passwors_creater = () => {
    let output = ''
    while (output.length < 4) {
        output += lowerAlph[Math.floor(Math.random() * lowerAlph.length)];
    }
    while (output.length < 5) {
        output += Characters[Math.floor(Math.random() * Characters.length)];
    }
    while (output.length < 6) {
        output += number[Math.floor(Math.random() * number.length)];
    }
    while (output.length < 7) {
        upperAlp
        output += upperAlp[Math.floor(Math.random() * upperAlp.length)];
    }
    while (output.length < 9) {
        output += number[Math.floor(Math.random() * number.length)];
    }
    while (output.length < 12) {
        output += lowerAlph[Math.floor(Math.random() * lowerAlph.length)];
    }
    password.value = output;
}

copy.addEventListener("click",()=>{
    navigator.clipboard.writeText(password.value)
    alert(`${password.value}has been copied to your clipboard` )
})

generate.addEventListener("click", passwors_creater)
let btn1 = document.querySelectorAll(".btn-type-one");
let btn2 = document.querySelectorAll(".btn-type-two");
var input = document.getElementById("input");
var output = document.getElementById("output");
btn1.forEach(element => {
    element.addEventListener("click", (e) => {
        // console.log(e.target.innerText);
        input.innerText += e.target.innerText;
        // console.log(input_output.innerText);
    })
});
btn2.forEach(element => {
    element.addEventListener("click", (e) => {
        switch (e.target.innerText) {
            case "AC":
                console.log(e.target.innerText);
                input.innerText = "";
                output.innerText = "";
                break;
            case "DE":
                let inpt_vlu = input.innerText.split("");
                inpt_vlu.pop();
                input.innerText = inpt_vlu.join("");
                break;

            case "=":
                try {
                    output.innerText = eval(input.innerText);
                } catch (error) {
                    alert("please provide valid input");
                    input.innerText = "";
                    output.innerText = "";
                }
                break;
        }
    })
})
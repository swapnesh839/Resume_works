let interval_rotate;
let rotation = 0;

function rotate(value) {
    let image = document.getElementById("image");
    if (value) {
        interval_rotate = setInterval(() => {
            rotation += 5;
            image.style.transform = `rotate(${rotation}deg)`;
        }, 60);
    } else {
        clearInterval(interval_rotate);
        rotation = 0;
    }
}

let play_pause = document.getElementById("play_pause");
let play_pause_icon = document.getElementById("play_pause_icon");
let music = document.getElementById("music");
let Range = document.getElementById("Range");
let author = document.getElementById("author");
let m_name = document.getElementById("m_name");

author.innerText = "Author: Unknown";
m_name.innerText = '"Unknown: is playing"';

play_pause.addEventListener("click", () => {
    if (play_pause_icon.classList.contains("fa-play")) {
        music.play();
        rotate(true);
        play_pause_icon.classList.replace("fa-play", "fa-pause");

        if (!music.paused) {
            function updateRange() {
                Range.value = (music.currentTime / music.duration) * 100; 
                requestAnimationFrame(updateRange);
                music.max= music.duration;
            }
            updateRange();
        }
    } else {
        music.pause();
        rotate(false);
        play_pause_icon.classList.replace("fa-pause", "fa-play");
    }
});


let src_index = 0;
let src = [
    "./a-long-way-166385.mp3",
    "./drive-breakbeat-173062.mp3",
    "./good-night-160166.mp3"
];

let backward = document.getElementById("backward");
let forward = document.getElementById("forward");

function src_change(e) {
    clearInterval(interval_rotate);

    if (e.target.id === "backward") {
        src_index = (src_index > 0) ? src_index - 1 : src.length - 1;
    } else {
        src_index = (src_index < src.length - 1) ? src_index + 1 : 0;
    }

    music.src = src[src_index];
    music.play();
    play_pause_icon.classList.replace("fa-play", "fa-pause");

    if (!music.paused) {
        rotate(true);

        function updateRange() {
            Range.value = music.currentTime;
        }
        updateRange();
    }
}

backward.addEventListener("click", src_change);
forward.addEventListener("click", src_change);

music.addEventListener("ended", () => {
    rotate(false);
    play_pause_icon.classList.replace("fa-pause", "fa-play");
});

const box = document.getElementById("box");
const btn = document.getElementById("btn");

btn.addEventListener("click", () => {

    let div = document.createElement("div")
    div.className = "notes-box col-8 mx-auto my-5 h-25 w-100 rounded-3 position-relative";
    let input = document.createElement("input")
    input.className = "mx-auto h-100 w-100 rounded-3 position-relative";
    input.type = "text"
    let img = document.createElement("img");
    img.src = "./red-trash-can-icon.png";
    img.className = "trash position-absolute";
    div.append(input);
    div.append(img);
    box.prepend(div);
    remove();

})

function remove() {
    const trash = document.querySelectorAll("img")
    trash.forEach((element) => {
        element.addEventListener("click", () => {
            element.parentElement.remove();
        })
    })
}

function storage() {
    localStorage(value,)
}


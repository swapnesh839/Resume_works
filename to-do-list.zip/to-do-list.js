const text_box = document.getElementById("text-box")
const btn = document.getElementById("btn")
const list_container = document.getElementById("list_container")


list_container.querySelectorAll('li').forEach(function (li) {
    li.classList.add("m-2", "p-2", "ps-3","position-relative");
});

function fetch() {
    if (text_box.value === '') {
        alert("Task Can't Empty")
    } else {
        let list = document.createElement("li");
        list.innerText = text_box.value;
        text_box.value = '';
        list_container.appendChild(list);
        let span = document.createElement("span");
        span .innerHTML="\u00d7";
        list.appendChild(span);
        list_container.querySelectorAll('li').forEach(function (li) {
            li.classList.add("m-2", "p-2", "ps-3","position-relative");
        });
    }
}
btn.addEventListener("click", fetch)

list_container.addEventListener("click",(event)=>{
    if (event.target.tagName === "LI") {
        event.target.classList.toggle("checked")
    } else if(event.target.tagName === "SPAN"){
        event.target.parentElement.remove()
    }
})
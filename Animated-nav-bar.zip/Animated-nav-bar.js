let nav_items = document.querySelectorAll(".nav-item");
nav_items.forEach((nav_item) => {
  nav_item.addEventListener("click", () => {
    nav_items.forEach((element) => {
      element.classList.remove("active");
    });
    nav_item.classList.add("active");
  });
});

let nav_items2 = document.querySelectorAll(".nav-item2");
nav_items2.forEach((nav_item2) => {
  nav_item2.addEventListener("click", () => {
    nav_items2.forEach((element2) => {
      element2.classList.remove("active2");
    });
    nav_item2.classList.add("active2");
  });
});

let nav_items3 = document.querySelectorAll(".nav-item3");
let nav3 = document.querySelector(".nav3");
nav_items3.forEach((nav_item3) => {
  nav_item3.addEventListener("click", () => {
    nav_items3.forEach((element3) => {
      element3.classList.remove("active3");
    });
    nav_item3.classList.add("active3");
    let active3 = document.querySelector(".active3");
    let ncolor = window.getComputedStyle(active3).backgroundColor;
    nav3.style.backgroundColor = ncolor;
  });
});
